DROP TABLE IF EXISTS `#__resource_welder`;
DROP TABLE IF EXISTS `#__resource_gas`;
DROP TABLE IF EXISTS `#__resource_welding`;
DROP TABLE IF EXISTS `#__resource_tech`;
DROP TABLE IF EXISTS `#__resource_workshop`;
DROP TABLE IF EXISTS `#__resource_machine`;
DROP TABLE IF EXISTS `#__resource_maintain`;