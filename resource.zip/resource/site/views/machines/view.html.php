<?php

// echo "san";die();

defined('_JEXEC') or die;

class ResourceViewMachines  extends JViewLegacy

{
	protected $items;


	public function display($tpl = null)
	{
	
		$this->items = $this->get('Item');

		parent::display($tpl);
	}	



}


?>