<?php

defined('_JEXEC') or die;

class ResourceControllerMachine extends JControllerForm
{
	public function manage() {
		call_user_func(array($this, isset($this->input->post->get('jform', array(), 'array')['edit']) ? 'edit' : 'save'));
	}
	
	public function edit($key = NULL, $urlVar = NULL){
		$data = $this->input->post->get('jform', array(), 'array');
		//	var_dump($data);die;
		$model = $this->getModel('machines');
		$ret = $model->edit($data);
		if($ret)
		{
			$this->setRedirect(JRoute::_('index.php?option=com_resource&view=machines', false));
		}
	}
	
	public function save($key = NULL, $urlVar = NULL){

		$data = $this->input->post->get('jform', array(), 'array');
		//	var_dump($data);
		$model = $this->getModel('machines');
		$ret = $model->save($data);
		if($ret)
		{
			$this->setRedirect(JRoute::_('index.php?option=com_resource&view=machines', false));
		}else{
			
		}
		
	}
	
	public function delete()
	{
		$data = $this->input->post->get('cid', array(), 'array');
		//var_dump($this->input->post);die;
		$model = $this->getModel('machines');
		$ret = $model -> delete($data);
		if($ret)
		{
			$this->setRedirect(JRoute::_('index.php?option=com_resource&view=machines', false));
		}
	}
	
	public function implement()
	{
		//var_dump($this->input->post);die;
		$name = $this->input->post->getString('person_name');
		$oper_time = $this->input->post->get('oper_time');
		$limit_time = $this->input->post->get('limit_time');
		$oper_name = $this->input->post->getString('oper_name');
		$data['name'] = isset($name) ? $name : null;
		$data['oper_time'] = isset($oper_time) ? $oper_time : null;
		$data['limit_time'] = isset($limit_time) ? $limit_time : null;
		$data['oper_name'] = isset($oper_name) ? $oper_name : null;
		//var_dump($this->input->post->get('oper_time'));die;
		$model = $this->getModel('machines');
		$ret = $model->saveWeihu($data);
		if($ret)
		{
			$this->setRedirect(JRoute::_('index.php?option=com_resource&view=machines', false));
		}else{
			
		}
	}
	
	public function route()
	{
		$from = $this->input->post->get('jform', array(), 'array');
		if(isset($from['guzhang']))
		{
			$this->guzhang();
		}else if(isset($from['delete'])){
			$this->delete();
		}else{
			$this->refreash();
		}

	}
	
	public function guzhang()
	{
		$this->setRedirect(JRoute::_('index.php?option=com_resource&from=guzhang', false));

	}
	
	public function refreash()
	{
		$this->setRedirect(JRoute::_('index.php?option=com_resource&view=machines', false));
	
	}
}