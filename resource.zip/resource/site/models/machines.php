<?php

defined('_JEXEC') or die;

class ResourceModelMachines extends JModelForm
{
	public function getForm($data = array(),$loadData =true)
	{
	
	}

	public function getItem()
	{
		$app = JFactory::getApplication();
		$from = $app->input->get('from');
		if(isset($from)){
			$db = JFactory::getDbo();
			$query = $db->getQuery(true);
				
			$query
				->select('*')
				->from($db->quoteName('#__resource_machine'))
				->where($db->quoteName('guzhang').'=1');
					
				
			//var_dump($query->__tostring());die;
			$db->setQuery($query);
			$results = $db->loadObjectList();
			//	var_dump($results);die;
			return $results;
		}else{
			$db = JFactory::getDbo();
			$query = $db->getQuery(true);
			
			$query
			->select($db->quoteName(array('id','sequence','coding','model','position',
					'pic','usetime','hanjietime','baoyantime','records','times')))
					->from($db->quoteName('#__resource_machine'));
				
			
			//var_dump($query->__tostring());die;
			$db->setQuery($query);
			$results = $db->loadObjectList();
			//	var_dump($results);die;
			return $results;
		}
		
	}
	
	public function loadFormData()
	{
		
	}
	
	public function saveWeihu($data)
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		
		$profile = new stdClass();
		$profile->welder_id = isset($data['welder_id']) ? $data['id'] : 1;
		$profile->person_name = $data['name'];
		$profile->oper_time= $data['oper_time'];
		$profile->limit_time=$data['limit_time'];
		$profile->oper_name = $data['oper_name'];
		
		try{
			
			$result = JFactory::getDbo()->insertObject('#__resource_maintain', $profile);
			
		}catch (Exception $e){
			return false;
		}
		
		return $result;
	}
	
	public function save($data)
	{
		//var_dump($data);die;
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
	
		$profile = new stdClass();
		$profile->sequence = $data['sequence'];
		$profile->coding= $data['coding'];
		$profile->model=$data['model'];
		$profile->position = $data['position'];
		$profile->pic= $data['pic'];
		$profile->usetime=$data['usetime'];
		$profile->hanjietime = $data['hanjietime'];
		$profile->baoyantime= $data['baoyantime'];
		$profile->records=$data['records'];
		$profile->times = $data['times'];
		$profile->workshopid= $data['workshopid'];
		$profile->guzhang = $data['guzhang'];
		try{
			$result = JFactory::getDbo()->insertObject('#__resource_machine', $profile);
		}catch (Exception $e){
			return false;
		}
		
		return $result;
	}
	
	public function edit($data)
	{
		//var_dump($data);die;
		$profile = new stdClass();
		$profile->id = $data['id'];
		$profile->sequence = $data['sequence'];
		$profile->coding= $data['coding'];
		$profile->model=$data['model'];
		$profile->position = $data['position'];
		$profile->pic= $data['pic'];
		$profile->usetime=$data['usetime'];
		$profile->hanjietime = $data['hanjietime'];
		$profile->baoyantime= $data['baoyantime'];
		$profile->records=$data['records'];
		$profile->times = $data['times'];
		$profile->workshopid= $data['workshopid'];
		$profile->guzhang = $data['guzhang'];
		
		try {
			$result = JFactory::getDbo()->updateObject('#__resource_machine', $profile, 'id');
		} catch (Exception $e) {
			return false;
		}		
		return $result;
	}
	
	public function delete($data)
	{
		$did = '('.implode(',',$data).')';
	
		$db = JFactory::getDbo();
	
		$query = $db->getQuery(true);
	
		// delete all custom keys for user 1001.
		$conditions = array(
				$db->quoteName('id') . 'in'.$did
		);
			
		$query->delete($db->quoteName('#__resource_machine'));
		$query->where($conditions);
		//	var_dump($query->__tostring());die;
		$db->setQuery($query);
		try {
			$result = $db->execute();
		} catch (Exception $e) {
			return false;
		}
		//var_dump($result);die;
		return $result;
		
	}
	

}