<?php

defined('_JEXEC') or die;

class ResourceModelMachine extends JModelForm
{
	public function getForm($data = array(),$loadData =true)
	{
	//	echo 'getform';die;
		$form = $this->loadForm('com_resource.machine', 'machine', array('control' => 'jform', 'load_data' => $loadData));
	
		if (empty($form))
		{
			return false;
		}

		return $form;
	}

	public function getItem()
	{
		$app = JFactory::getApplication();
		$id = $app->input->get('id',null);
		//var_dump($id);die;
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		
		$query
			->select('*')
			->from($db->quoteName('#__resource_machine'))
			->where($db->quoteName('id').'='.$id);
		
		//var_dump($query->__tostring());die;
		$db->setQuery($query);
		try {
			$results = $db->loadObject();
		} catch (Exception $e) {
			return false;
		}
			
		return $results;
	}
	
	public function loadFormData()
	{
		$data = JFactory::getApplication()->getUserState('com_resource.edit.machine.data', array());
		
		if (empty($data))
		{
			$data = $this->getItem();

		}
		
		$this->preprocessData('com_resource.machine', $data);
		
		return $data;
	}
	
	public function getMaintain($data)
	{
		//var_dump($data);die;
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		
		$query
			->select($db->quoteName(array('id', 'person_name', 'oper_time', 'limit_time', 'oper_name')))
			->from($db->quoteName('#__resource_maintain'))
			->where($db->quoteName('welder_id').'='.$data);
	
		$db->setQuery($query);

		try{
			$ret = $db->loadObjectList();
		}catch (Exception $e){
			return false;
		}
		return $ret;
		
	}
	
	public function guzhang()
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		
		$query
		->select('*')
		->from($db->quoteName('#__resource_machine'))
		->where($db->quoteName('guzhang').'=1');
		
		//var_dump($query->__tostring());die;
		$db->setQuery($query);
		
		try {
			$results = $db->loadObjectList();
		} catch (Exception $e) {
			return false;
		}
			
		return $results;
	}

}