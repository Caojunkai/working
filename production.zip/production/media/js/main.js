jQuery(document).ready(function($){
    $("#iframepage").attr("height",$(".component").height());
    $(".but-1").bind("click",function(){
        $("#iframepage").attr("src","http://www.baidu.com");
    });
    $(".but-2").bind("click",function(){
        $("#iframepage").attr("src","http://www.weibo.com");
    });
    $(".but-3").bind("click",function(){
        $("#iframepage").attr("src","http://www.douban.com/");
    });
    $(".but-work").bind("click",function(){
        $.ajax({
            url:"index.php?option=com_production&task=global.showMachine&format=json",
            type:"post",
            dataType:"json",
            data:{
                id:$(this).val()
            },
            success: function(data){
                $(".detail").empty();
                var detail = $(".detail");
                $.each(data,function(key,value){
                    switch (value.state){
                        case "0" :
                            detail.append("<span class='sp off' data-id='"+value.id+"'>"+value.coding+"</span>");
                            break;
                        case "1" :
                            detail.append("<span class='sp normal' data-id='"+value.id+"'>"+value.coding+"</span>");
                            break;
                        case "2" :
                            detail.append("<span class='sp warning' data-id='"+value.id+"'>"+value.coding+"</span>");
                            break;
                        case "3" :
                            detail.append("<span class='sp error' data-id='"+value.id+"'>"+value.coding+"</span>");
                            break;
                    }
                });
                $("#iframepage").attr("height",$(".component").height());
            }
        })

    });
});