<?php
defined('_JEXEC') or die;
JHtml::_('behavior.formvalidator');
$doc = JFactory::getDocument();
$doc->addStyleSheet('media/com_production/css/main.css');
$doc->addScript('media/com_production/js/main.js');
?>
<div class="left">
		<div class="toolbar-box">
				<button class="but but-1">实时曲线</button>
				<button class="but but-2">历史曲线</button>
				<button class="but but-3">自动翻页</button>
				<button class="but but-4">全部焊机</button>
		</div>
		<div class="workshop">
			<?php foreach ($this->workshop as $row) : ?>
				<button class="but but-work" value="<?php echo $row->id; ?>"><?php echo $row->name;  ?></button>
			<? endforeach; ?>
		</div>
		<div class="detail">

		</div>
		<div class="pageturn">
				<button class="but-page-pre">上一页</button>
				<button class="but-page-next">下一页</button>
		</div>
</div>
<div class="maincontent">
	<iframe id="iframepage" src="http://arcticfox.sinaapp.com/admin" frameborder="0"  scrolling="auto"></iframe>
</div>
<script>

</script>