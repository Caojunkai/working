<?php
defined('_JEXEC') or die;

class ProductionTableGlobal extends JTable{

	/**
	 * Constructor
	 *
	 * @param   JDatabaseDriver  &$db  A database connector object
	 */
	function __construct(&$db)
	{
		parent::__construct('#__resource_workshop', 'id', $db);
	}
}