CREATE TABLE IF NOT EXISTS `#__pswelder_welder` (
	`id`INT NOT NULL PRIMARY KEY,
	`welder_name` varchar(150) NOT NULL COMMENT '焊工姓名',
	`code` varchar(150) NOT NULL COMMENT '焊工编号',
	`teamwork` varchar(150) NOT NULL,
	`identify` varchar(128) DEFAULT '' COMMENT '资格证编号',
	`cert_deadline`  date DEFAULT '0000-00-00' COMMENT '资格证到期时间',
	`work_start`  date DEFAULT '0000-00-00' COMMENT '上岗时间',
	`weld_type` varchar(100) DEFAULT '' COMMENT '焊接位置',
	`weld_phone` VARCHAR(20) DEFAULT '' COMMENT '焊工电话',
	`weld_available` TINYINT(2) NOT NULL COMMENT '是否可用 0可用 1不可用',
	`remark` VARCHAR(100) COMMENT '备注',
	INDEX `welder_name`(`welder_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `#__pswelder_machine` (
	`id` int(10) NOT NULL ,
	`machine_code` varchar(20) DEFAULT '' COMMENT '编号',
	`machine_type` varchar(20) DEFAULT '' COMMENT '焊机类型',
	`machine_model` VARCHAR(30) COMMENT '焊机型号',
	`machine_workshop` INT(11) NOT NULL COMMENT '车间ID',
	`position` varchar(30) DEFAULT '' COMMENT '安装位置',
	`response_person` INT(11) NOT NULL  COMMENT '责任人员',
	`use_time` date DEFAULT '0000-00-00' COMMENT '使用日期',
	`weld_time` varchar(20) DEFAULT '' COMMENT '焊接时间',
	`machine_wsn_code` VARCHAR(20) COMMENT '焊机无线编码',
	`machine_current` VARCHAR(20) COMMENT '焊机电流方式',
	`machine_pulse` VARCHAR(10) COMMENT '焊机脉冲方式',
	`machine_load` VARCHAR(10) COMMENT '焊机负载率',
	`machine_factory` VARCHAR(20) COMMENT '厂家',
	`machine_data` date DEFAULT '0000-00-00' COMMENT '采购日期',
	`update_time` datetime DEFAULT '0000-00-00 00:00:00' COMMENT '数据更新时间',
	`available` TINYINT(2) NOT NULL COMMENT '是否可用',
	`machine_name` VARCHAR(20) COMMENT '机器名称',
	`temp_meter_id` INT(10) DEFAULT 0,
	PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `#__pswelder_workshop` (
	`id` int(10) NOT NULL ,
	`workshop_code` varchar(10)  NOT NULL COMMENT '车间编号',
	`workshop_name` varchar(60)  NOT NULL COMMENT '车间名称',
	`date` date DEFAULT '0000-00-00' COMMENT '使用日期',
	`remark` VARCHAR(100)  COMMENT '备注',
	`available` TINYINT(2) NOT NULL COMMENT '是否可用',
	PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `#__pswelder_wps` (
	`id` INT(11) NOT NULL,
	`wps_code`varchar(150) NOT NULL COMMENT '文件编号',
	`current_method` VARCHAR(30) COMMENT '焊接电流方式',
	`name` varchar(150) NOT NULL COMMENT '名称',
	`site` varchar(256) NOT NULL COMMENT '焊接位置',
	`weld_arg` varchar(256) NOT NULL COMMENT '焊接参数',
	`board_arg` varchar(256) NOT NULL COMMENT '板材参数',
	`speed` varchar(256) NOT NULL COMMENT '送丝速度',
	`welding` varchar(256) NOT NULL COMMENT '所用的焊丝',
	`gas_arg` varchar(256) NOT NULL COMMENT '气体参数设置',
	`weld_site` varchar(256) NOT NULL COMMENT '焊接位置图',
	`voltage_min` INT(10) NOT NULL COMMENT '最低电压',
	`voltage_max` INT(10) NOT NULL COMMENT '最高电压',
	`weld_speed` int(10) NOT NULL COMMENT '焊接速度',
	`weld_tech` varchar(256) NOT NULL COMMENT '焊接工艺图资料',
	`i` varchar(256) NOT NULL COMMENT '电流',
	`v` varchar(256) NOT NULL COMMENT '电压',
	`consumable` varchar(256) NOT NULL COMMENT '耗材',
	`gas_name` varchar(256) NOT NULL COMMENT '气体名称',
	`gas_flow` varchar(256) NOT NULL COMMENT '气体流量',
	`current_min` INT(10) NOT NULL COMMENT '电流下限',
	`current_max` INT(10) NOT NULL COMMENT '电流上限',
	`is_show` INT(10),
	PRIMARY KEY (`id`),
	INDEX `name`(`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE IF NOT EXISTS `#__pswelder_gas`(
 	`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	`name` VARCHAR(30) NOT NULL COMMENT '气体名称',
	`label` VARCHAR(30) COMMENT '气体牌号',
	`norm` VARCHAR(30) COMMENT '气体规格',
	`code`  VARCHAR(30) DEFAULT '' NOT NULL COMMENT '气体编号'
)ENGINE=InnoDB AUTO_INCREMENT =1 DEFAULT CHARSET =utf8;

CREATE TABLE IF NOT EXISTS `#__pswelder_metal`(
	`id` INT(11) NOT NULL,
	`density` VARCHAR(10) COMMENT '焊丝密度',
	`welding_metal` VARCHAR(30) NOT NULL COMMENT '焊接材料代号 焊丝编号',
	`filler_metal` VARCHAR(30) NOT NULL COMMENT '填充金属 焊丝种类',
	`filler_size_type` VARCHAR(30) NOT NULL COMMENT '填充金属规格 焊丝直径',
	`filler_lot_no` VARCHAR(30) NOT NULL COMMENT '填充金属批号',
	`filler_manager_no` VARCHAR(30) NOT NULL COMMENT '填充金属管理号',
	`flux` VARCHAR(30) NOT NULL COMMENT '焊剂',
	`flux_lot_no` VARCHAR(30) NOT NULL COMMENT '焊剂批号',
	`flux_manager_no` VARCHAR(30) NOT NULL COMMENT '焊剂管理号',
	`desc`  TEXT COMMENT '说明 描述',
	PRIMARY KEY (`id`)
)ENGINE InnoDB AUTO_INCREMENT = 1 DEFAULT CHARSET =utf8;

CREATE TABLE IF NOT EXISTS `#__pswelder_maintain` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`welder_id` int(11) NOT NULL COMMENT '保养人员',
	`machine_id` int(11) NOT NULL COMMENT '焊机ID',
	`oper_time` datetime DEFAULT '0000-00-00 00:00:00' COMMENT '操作时间',
	`limit_time` varchar(20) DEFAULT '' COMMENT '本次保养有效期',
	`oper_name` text DEFAULT '' COMMENT '实施项目名称',
	PRIMARY KEY (`id`),
	INDEX `machine_id`(`machine_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `#__pswelder_user_workshop`(
	`id` INT(11) NOT NULL ,
	`user_id` INT(10) NOT NULL,
	`workshop_id` INT(10) NOT NULL,
	`whorkshop_name` VARCHAR(20) DEFAULT '',
	PRIMARY KEY (`id`)
)ENGINE=InnoDB  DEFAULT CHARSET=utf8;

