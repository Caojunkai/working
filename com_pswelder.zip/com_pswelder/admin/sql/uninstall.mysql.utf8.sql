DROP TABLE IF EXISTS `#__pswelder_welder`;
DROP TABLE IF EXISTS `#__pswelder_machine`;
DROP TABLE IF EXISTS `#__pswelder_workshop`;
DROP TABLE IF EXISTS `#__pswelder_wps`;
DROP TABLE IF EXISTS `#__pswelder_gas`;
DROP TABLE IF EXISTS `#__pswelder_metal`;
DROP TABLE IF EXISTS `#__pswelder_maintain`;
DROP TABLE IF EXISTS `#__pswelder_user_workshop`;

