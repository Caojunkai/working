<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_content
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
if (JFactory::getUser()->guest){
		JFactory::getApplication()->enqueueMessage(JText::_('请先登录'), 'message');
		return ;
}

$params = JComponentHelper::getParams('com_pswelder');
if (!$params->get('thrift_server') || !$params->get('thrift_port')) {
	JFactory::getApplication()->enqueueMessage(JText::_('请先设置thrift服务器或者端口'), 'message');
		return ;
}

JLoader::register('PswelderFactory', __DIR__ . '/helpers/factory.php');

$input = JFactory::getApplication()->input;


$controller = JControllerLegacy::getInstance('Pswelder', ['modeltype' => $input->get('layout')]);
$controller->execute(JFactory::getApplication()->input->get('task', 'display'));
$controller->redirect();
