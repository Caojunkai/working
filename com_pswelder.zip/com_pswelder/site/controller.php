<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_content
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

/**
 * Content Component Controller
 *
 * @since  1.5
 */
class PswelderController extends JControllerLegacy {
	
	protected $type;
	
	public function __construct($config = array()) {
		$this->type = @$config['modeltype'];
		parent::__construct($config);
	}
	
	/**
	 * Method to load and return a model object.
	 *
	 * @param   string  $name    The name of the model.
	 * @param   string  $prefix  Optional model prefix.
	 * @param   array   $config  Configuration array for the model. Optional.
	 *
	 * @return  mixed   Model object on success; otherwise null failure.
	 *
	 * @since   12.2
	 * @note    Replaces _createModel.
	 */
	protected function createModel($name, $prefix = '', $config = array()) {
		if(strtolower($prefix) == 'psweldermodel' && in_array(strtolower($name), ['list', 'item', 'monitor'])) {
			$config['modeltype'] = $this->type;
			if($name == 'item' || $name == 'monitor') {
				$config['itemId'] = @$this->input->getint('id');
			}
		}
		return parent::createModel($name, $prefix, $config);
	}
	

	/**
	 * Method to display a view.
	 *
	 * @param   boolean  $cachable   If true, the view output will be cached.
	 * @param   boolean  $urlparams  An array of safe url parameters and their variable types, for valid values see {@link JFilterInput::clean()}.
	 *
	 * @return  JController  This object to support chaining.
	 *
	 * @since   1.5
	 */
	public function display($cachable = false, $urlparams = false)
	{
		/**
		 * Set the default view name and format from the Request.
		 * Note we are using a_id to avoid collisions with the router and the return page.
		 * Frontend is a bit messier than the backend.
		 */
		$this->input->set('view', $this->input->get('view', 'list'));
		$this->input->set('layout', 'default');
		$safeurlparams = array(
			'catid' => 'INT',
			'id' => 'INT',
			'cid' => 'ARRAY',
			'year' => 'INT',
			'month' => 'INT',
			'limit' => 'UINT',
			'limitstart' => 'UINT',
			'showall' => 'INT',
			'return' => 'BASE64',
			'filter' => 'STRING',
			'filter_order' => 'CMD',
			'filter_order_Dir' => 'CMD',
			'filter-search' => 'STRING',
			'print' => 'BOOLEAN',
			'lang' => 'CMD',
			'Itemid' => 'INT');

		parent::display($cachable, $safeurlparams);
		
		return $this;
	}
}
