<?php
/**
 * show the item.
 */

defined('_JEXEC') or die;

?>
<form action="<?php echo JRoute::_('index.php?option=com_pswelder'); ?>"
    method="post" name="adminForm" id="adminForm">
    <div class="form-horizontal">
        <fieldset class="adminform">
              <legend><?php echo $this->get('itemtitle'); ?>详细信息</legend>
            <div class="row-fluid">
                <div class="span 9">
                    <?php foreach ($this->form->getFieldset() as $field): ?>
                  	  <?php if(!$field->hidden) : ?>
                        <div class="control-group">
                            <div class="control-label"><?php echo $field->label; ?></div>
                            <div class="controls" style="line-height: 28px;"><?php echo $field->value; ?></div>
                        </div>
                        <?php endif;?>
                    <?php endforeach; ?>
                </div>
            </div>
        </fieldset>
    </div>
    <div class="control-group">
			<div class="controls">
				
				<a href="<?php echo JRoute::_('index.php?option=com_pswelder&view=item&role=edit&id='.JFactory::getApplication()->input->get('id').'&layout=' . $this->get('modeltype')); ?>"><button type="button"class="btn btn-default btn-primary" style="margin-left: 200px;margin-right: 30px"><span class="icon-cancel"></span>编辑</button></a>
				<a href="<?php echo JRoute::_('index.php?option=com_pswelder&view=list&layout=' . $this->get('modeltype')); ?>"><button type="button" class="btn"><span class="icon-cancel"></span>取消</button></a>
				
			</div>
		</div>
 
    <?php echo JHtml::_('form.token'); ?>
</form>

