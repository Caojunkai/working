<?php
defined('_JEXEC') or die;


JHtml::_('jquery.framework');
JHtml::_('bootstrap.framework');
JHtml::script('com_pswelder/jquery.bxslider.min.js', false, true);
JHtml::script('com_pswelder/highcharts.js', false, true);
JHtml::script('com_pswelder/realtime.js', false, true);

JFactory::getDocument()->addScriptDeclaration('
function getConfig(){
	var config={
			url:"ws://' . JComponentHelper::getParams('com_pswelder')->get('thrift_server', 'localhost') . ':8081/welding.realtime/realtime",
			maxx: 20,
			maxv: 300,
			minv: 0,
			maxc: 300,
			minc: 0,
			pause:2000,
			speed:200,
			warn_color: "#FF0000",
			vorwarn_color: "#FFAA00",
			base_color: "#336600"
			
	};
	return config;
}
		
var config=getConfig();
		
			var max = config.maxx;
			var autoScroll = true;
			var sliders = new Array();

			var array1 = new Array();
			//machines list1
			var array2 = new Array();
			//machines list2
			var array3 = new Array();
			//machines list3
			var array4 = new Array();
			//machines list4
			var pool = [array1, array2, array3, array4];
			var untouched = new Array();

			var machineMap = new Object();
			var vChartMap = new Object();
			var cChartMap = new Object();
');

JHtml::stylesheet('jui/bootstrap.min.css', array(), true);
JHtml::stylesheet('com_pswelder/jquery.bxslider.css', array(), true);
?>
<div class="container-fluid">
<?php if($this->layout == 'item'): ?>
<?php JHtml::script('com_pswelder/single.js', false, true);?>
<div class="row-fluid">
				<div class="row-fluid">
					<div class="span2 offset5">
						<h4 class="slider1">Title</h4>
					</div>
				</div>
				<div class="row-fluid">
					<div class="span6">
						<div class="vChart"></div>
					</div>
					<div class="span6">
						<div class="cChart"></div>
					</div>
				</div>
			</div>
<?php else:?>
<?php JHtml::script('com_pswelder/all.js', false, true); ?>
			<div class="row-fluid">
				<div class="span6" >
					<div class="row-fluid">
						<div class="span2 offset5">
							<h4 class="slider1">Title</h4>
						</div>
					</div>
					<div class="row-fluid">

						<div id="slider1" class="slider">
							<div class="row-fluid" >
								<div class="span6">
									<div class="vChart"></div>
								</div>
								<div class="span6">
									<div class="cChart"></div>
								</div>
							</div>
							<div class="row-fluid">
								<div class="span6">
									<div class="vChart"></div>
								</div>
								<div class="span6">
									<div class="cChart"></div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="span6" >
					<div class="row-fluid">
						<div class="span2 offset5">
							<h4 class="slider2">Title</h4>
						</div>
					</div>
					<div class="row-fluid">
						<div id="slider2" class="slider">
							<div class="row-fluid" >
								<div class="span6">
									<div class="vChart"></div>
								</div>
								<div class="span6">
									<div class="cChart"></div>
								</div>
							</div>
							<div class="row-fluid">
								<div class="span6">
									<div class="vChart"></div>
								</div>
								<div class="span6">
									<div class="cChart"></div>
								</div>
							</div>

						</div>
					</div>
				</div>
			</div>

			<div class="row-fluid">
				<div class="span6" >
					<div class="row-fluid">
						<div class="span2 offset5">
							<h4 class="slider3">Title</h4>
						</div>
					</div>
					<div class="row-fluid">
						<div id="slider3" class="slider">
							<div class="row-fluid" >
								<div class="span6">
									<div class="vChart"></div>
								</div>
								<div class="span6">
									<div class="cChart"></div>
								</div>
							</div>
							<div class="row-fluid">
								<div class="span6">
									<div class="vChart"></div>
								</div>
								<div class="span6">
									<div class="cChart"></div>
								</div>
							</div>

						</div>
					</div>
				</div>
				<div class="span6" >
					<div class="row-fluid">
						<div class="span2 offset5">
							<h4 class="slider4">Title</h4>
						</div>
					</div>
					<div class="row-fluid">
						<div id="slider4" class="slider">
							<div class="row-fluid" >
								<div class="span6">
									<div class="vChart"></div>
								</div>
								<div class="span6">
									<div class="cChart"></div>
								</div>
							</div>
							<div class="row-fluid">
								<div class="span6">
									<div class="vChart"></div>
								</div>
								<div class="span6">
									<div class="cChart"></div>
								</div>
							</div>

						</div>
					</div>
				</div>
			</div>
<?php endif;?>
		</div>

