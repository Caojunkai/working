<?php
defined('_JEXEC') or die;

class PswelderViewDashboard extends JViewLegacy{

	public function display($tpl = NULL)
	{
		parent::display($tpl);
	}

}
