<?php
defined('_JEXEC') or die;
JHtml::_('formbehavior.chosen', 'select');
$listOrder     = $this->escape($this->state->get('list.ordering'));
$listDirn      = $this->escape($this->state->get('list.direction'));

$contents = $this->get('listcontent');
$keys = array_keys($contents);
$primary_key = $this->get('primarykey');

$base_url = JRoute::_('index.php?option=com_pswelder', false);
?>


<form action="<?php echo $base_url; ?>" method="post" id="adminForm" name="adminForm">
	<div class="row-fluid">
		<div class="span6">
			<h3><?php echo $this->get('listtitle'); ?>管理列表</h3>
			<?php
			echo JLayoutHelper::render(
					'joomla.searchtools.default',
					array('view' => $this)
			);
			?>
		</div>
	</div>
	<button type="submit" name="submit" value="add" class="btn btn-primary btn-success"><span class="icon-new"></span>新建</button>
	
	<button type="submit" name="submit" value="delete" class="btn btn-danger"><span class="icon-delete"></span>删除</button>
	<input type="hidden" name="task" value="item.manage">
	<input type="hidden" name="datatype" value="<?php echo $this->get('modeltype');?>">
	<?php echo JHtml::_('form.token'); ?>
<table class="table table-striped table-hover">
	<thead>
	<tr>
		<th width="3%">
			<input type="checkbox" name="toggle" value="" onclick="Joomla.checkAll(this)" />
		</th>
		<?php
		$width = intval(90/count($contents));
		foreach ($contents as $key => $value):
		?>
		<th class="grid_<?php echo $key;?> center">
			<?php echo JHtml::_('grid.sort', $value, $key, $listDirn, $listOrder);?>
		</th>
		<?php endforeach;?>
		<th width="5%"></th>
	</tr>
	</thead>
	<tfoot>
	<tr>
		<td colspan="6">
			<?php echo $this->pagination->getListFooter(); ?>
		</td>
	</tr>
	</tfoot>
	<tbody>
	<?php foreach ($this->items as $i => $item):?>
		<?php
			$item_url = $base_url . '?view=item&id=' . $item->$primary_key . '&data=' . $this->get('modeltype');
		?>
		<tr class="row<?php echo $i % 2; ?>" >
			<td class="center">
				<?php echo JHtml::_('grid.id', $i, $item->$primary_key); ?>
			</td>
			<?php foreach ($keys as $key): ?>
			<td class="center">
				<?php echo $this->escape($item->$key); ?>
			</td>
		<?php endforeach;?>
			<td class="center">
				<a href="<?php echo $item_url; ?>" class="btn" style="line-height:10px; padding:2px;"><span class="icon-eye-open" style="margin:0;"></span></a>
				<a href="<?php echo $item_url . '&layout=edit';?>" class="btn btn-warning" style="line-height:10px; padding:2px;"><span class="icon-edit"  style="margin:0;"></span></a>
			</td>
		</tr>
	<?php endforeach; ?>
	</tbody>
</table>
</form>
