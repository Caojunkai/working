<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_helloworld
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die('Restricted access');

/**
 * Hello Table class
 *
 * @since  0.0.1
 */
class PswelderTableItem extends JTable
{
	/**
	 * Constructor
	 *
	 * @param   JDatabaseDriver  &$db  A database connector object
	 */
	public function __construct($table, $key, $autoincrement = false)
	{
		parent::__construct('#__' . $table, $key, JFactory::getDbo());
		$this->_autoincrement = $autoincrement;
	}
	
	public function deleteItems($pks){
		try{
			$db = $this->getDbo();
			$query = $db->getQuery(true);
			$query->delete($db->quoteName($this->getTableName()))
			->where($db->quoteName('id')." IN (".implode(',',$db->quote($pks)).")");
			$db->setQuery($query);
			$db->execute();
		}catch (Exception $e){
			return false;
		}
			
		return true;
	}

}
