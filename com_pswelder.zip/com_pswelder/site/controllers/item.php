<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_jobtemplate
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
/**
 * HelloWorld Controller
 *
 * @package     Joomla.Administrator
 * @subpackage  com_jobtemplate
 * @since       0.0.9
 */
class PswelderControllerItem extends JControllerForm
{
	/**
	 * Constructor.
	 *
	 * @param   array  $config  An optional associative array of configuration settings.
	 *
	 * @see     JControllerLegacy
	 * @since   3.2
	 */
	public function __construct($config = array())
	{
		$this->view_list = 'list';
		$this->view_item = 'item';
		parent::__construct($config);
	}
	
	public function getModel($name = '', $prefix = '', $config = array('ignore_request' => true))
	{
		$config['modeltype'] = $this->context;
		$config['itemId'] = $this->input->post->get('pkey');
		return parent::getModel(empty($name) ? 'item' : $name, $prefix, $config);
	}
	
	public function delete(){
		
		// Check for request forgeries.
		JSession::checkToken() or jexit(JText::_('JINVALID_TOKEN'));
		$app   = JFactory::getApplication();
		$model = $this->getModel();
		$cid   = $this->input->post->get('cid', array(), 'array');
		$recordId = (int) (count($cid) ? $cid[0] : $this->input->getInt('id'));
		if (empty($recordId) || !$this->allowEdit(array('id' => $recordId), 'id'))
		{
			$this->setMessage('删除失败', 'error');
			$this->setRedirect(	JRoute::_('index.php?option=' . $this->option . '&view=' . $this->view_list	. $this->getRedirectToListAppend(), false));
			return false;
		}
		if($model->delete($cid)){
			$this->setMessage('删除成功');
		}else{
			$this->setMessage('删除失败', 'error');
			
		}
		$this->setRedirect(	JRoute::_('index.php?option=' . $this->option . '&view=' . $this->view_list	. $this->getRedirectToListAppend(), false));
		return true;
	}
	

	public function manage(){
		$this->context = $this->input->get('layout');
		return call_user_func(array($this, empty($this->input->post->get('submit')) ? 'display' : $this->input->post->get('submit')));
		
	}

	public function implement()
	{
		$data = $this->input->post->get('jform', array(), 'array');
		$cid = explode(',',$data['cid']);
		unset($cid[0]);
		unset($data["cid"]);
		$model = $this->getModel('machines','WeldResourceModel');
		$result = $model->saveImplement($cid,$data);
		if($result)
		{
			$this->setMessage('操作成功');
			$this->setRedirect(JRoute::_('index.php?option=com_weldresource&view=machines', false));
		}else{
			$this->setMessage('操作成功','error');
		}
	}
	
	protected function getRedirectToItemAppend($recordId = null, $urlVar = 'id') {
		return parent::getRedirectToItemAppend($recordId, $urlVar) . '&role=' . $this->input->get('role', 'edit', 'string');
	}
	
	protected function getRedirectToListAppend(){
		return parent::getRedirectToItemAppend($recordId, $urlVar) . '&layout=' . $this->context;
	}

}
