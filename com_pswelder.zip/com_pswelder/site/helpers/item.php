<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_content
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

include JPATH_COMPONENT . '/pswelder/thrift/PswelderService.php';
include JPATH_COMPONENT . '/pswelder/thrift/Types.php';

use pswelder\thrift\Request as PswelderRequest;
use pswelder\thrift\Constant as PswelderConstant;
use pswelder\thrift\InvalidOperation as PswelderInvalidOperation;


/**
 * Content component helper.
 *
 * @since  1.6
 */
abstract class PswelderHelperItem {
	
	public static function insert(JTable $table, $data) {
		$request = new PswelderRequest(array('clazz' => $data['thrift']['clazz'], 'func' => PswelderConstant::get('FUNC_INSERT')));
		$params = JComponentHelper::getParams('com_pswelder');
		$thrift = PswelderFactory::getThriftClient('pswelder\thrift\PswelderServiceClient', $params->get('thrift_server', 'localhost'), (int) $params->get('thrift_port', 7911));
		if(0 >= $response = $thrift->perform('execute', $request, $data['thrift']['request_data'])) {
			return false;
		}
		
		$data[$table->getKeyName()] = $response;
		
		if(!$table->save($data)){
			return false;
		}
		return $table->id;
	}
	
	public static function update(JTable $table, $data) {
		$request = new PswelderRequest(array('clazz' => $data['thrift']['clazz'], 'func' => PswelderConstant::get('FUNC_UPDATE')));
		$params = JComponentHelper::getParams('com_pswelder');
		$thrift = PswelderFactory::getThriftClient('pswelder\thrift\PswelderServiceClient', $params->get('thrift_server', 'localhost'), (int) $params->get('thrift_port', 7911));
		if(0 >= $response = $thrift->perform('execute', $request, $data['thrift']['request_data'])) {
			return false;
		}
		
		if(!$table->save($data)){
			return false;
		}
		
		return true;
	}
	

	public static function delete(JTable $table, array $pks, $data){
		$request = new PswelderRequest(array('clazz' => $data['thrift']['clazz'], 'func' => PswelderConstant::get('FUNC_DELETE')));
		$params = JComponentHelper::getParams('com_pswelder');
		
		$thrift = PswelderFactory::getThriftClient('pswelder\thrift\PswelderServiceClient', $params->get('thrift_server', 'localhost'), (int) $params->get('thrift_port', 7911));
		
		if(0 < $response = $thrift->perform('execute', $request, $data['thrift']['request_data'])) {
			if ($table->deleteItems($pks)){
				return true;
			}
			//@todo rollback
		}
		return false;
	}
	

}
