<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_users
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

/**
 * Users Route Helper
 *
 * @since  1.6
 */
class PsweldHelperlist
{
	private $name;
	
	private $path = '/list';
	
	private $ini ;
	
	public function __construct($name){
		$this->name = $name;
		jimport( 'joomla.filesystem.folder' );
		$this->ini = $this->getIni();
	}
	
	public function getSelect(){
		if( !isset($this->ini['select']) || !is_array($this->ini) ){
			throw new RuntimeException(' Select ' . $this->name . ' cannot be found.', 500);
		}
		return $this->ini['select'];
		
	}
	
	public function getConfig(){
	
		if(!isset($this->ini['config']) || !isset($this->ini['select']) || !is_array($this->ini) ){
			throw new RuntimeException('Config or Select ' . $this->name . ' cannot be found.', 500);
		}
		return $this->ini['config'];
	}
	
	private function getIni(){
		$ini = JFolder::files(__DIR__.$this->path,'.ini');
		if(!in_array($this->name.'.ini', $ini) || !($file = parse_ini_file(__DIR__.$this->path.'/'.$this->name.'.ini',true))){
			throw new RuntimeException('File ' . $this->name . ' cannot be found.', 500);
		}
		return $file;
	
	}
}
