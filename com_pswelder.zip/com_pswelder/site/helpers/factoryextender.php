 <?php
 
class PlgSystemFactoryExtender extends JPlugin {	
	public function onAfterInitialise() {
		
		
	}
}
	
?>