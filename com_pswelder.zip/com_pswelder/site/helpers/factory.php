 <?php
//@todo Use reflection or some dynamic method to load the extended source

use Thrift\ThriftClient; 
 
class PswelderFactory extends JFactory {
	static public $db_ocal;
	
	static public $thrift;
	
	static public function getOraclDB() {
		if(!isset(self::$db_ocal)) {
			self::$db_ocal = new PDO('oci:dbname=//192.168.0.70:1521/orcl', 'precise', 'precise');
		}
		return self::$db_ocal;
	}
	
	static public function getThriftClient($class_name, $host = 'localhost', $port = 7911) {
		if(!isset(self::$thrift)) {
			self::$thrift = new ThriftClient($class_name, $host, $port);
		}
		
		return self::$thrift;
	}
}
	
