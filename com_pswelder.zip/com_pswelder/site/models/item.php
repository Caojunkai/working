<?php
use Joomla\Utilities\ArrayHelper;
/**
 * @package     Joomla.Site
 * @subpackage  com_content
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

JLoader::register('PswelderHelperItem',  JPATH_COMPONENT. '/helpers/item.php');

/**
 * 
 * @todo User ArrayHelper::getValue to get value from config file
 * 
 */
class PswelderModelItem extends JModelForm
{
	protected $type;
	protected $list_config;
	protected $primary_table;
	
	protected $item_helpers = null;
	
	protected $id = null;
	
	public function __construct($config = array()){
		if(!isset($config['modeltype']) || !file_exists($file = JPATH_COMPONENT . '/models/configs/' . $config['modeltype'] . '.ini')) {
			throw new RuntimeException('Invalid access of contents.');
		}
		$this->type = $config['modeltype'];
		$this->setItemId(@$config['itemId']);
		if(!$this->list_config = parse_ini_file($file, true)) {
			throw new Exception('Config File wrong');
		}
		
		$this->primary_table = @$this->list_config['primary_table'];
		
		// Check if the table for list is checked.
		if(empty($this->list_config['tables'])) {
			throw new RuntimeException('No table is set.');
		}
		
		if(!$this->primary_table){
			$this->primary_table = key($this->list_config['tables']);
		} else {
			if(!key_exists($this->primary_table, $this->list_config['tables'])) {
				throw new RuntimeException('Primary table is not set.');
			}
		}

		parent::__construct($config);	
	}
	
	protected function setItemId($id = null) {
		if($id === null || is_int($id)) {
			$this->id = $id;
		} elseif (is_string($id)) {
			if(empty($id)) {
				$this->id = null;
			} else {
				$this->id = (int) $id;
			}
		}
	}
	
	public function getTable($name = '', $prefix = 'Table', $options = array()) {
		if(!empty($args = func_get_args())){
			parent::getTable($name, $prefix, $options);
		}
		
		JLoader::register('PswelderTableItem', JPATH_COMPONENT . '/tables/item.php');
		$autoincrement = isset($this->list_config['tables'][$this->primary_table]['primary_key_autoincrement']) ? (boolean) $this->list_config['tables'][$this->primary_table]['primary_key_autoincrement'] : true;
		return new PswelderTableItem($this->primary_table, $this->list_config['tables'][$this->primary_table]['primary_key'], $autoincrement);
	}

	public function getForm($data = array(), $loadData = true) {
		
		if (!$form = $this->loadForm('model.item.' . $this->type, null, array(	'control' => 'jform','load_data' => $loadData))) {
			return false;
		}
		
		return $form;
	}
	
	/**
	 *
	 * {@inheritDoc}
	 * @Override
	 * @see JModelForm::loadForm()
	 */
	protected function loadForm($name, $source = null, $options = array(), $clear = false, $xpath = false) {
		if($source !== null) {
			return parent::loadForm($name, $source, $options, $clear, $xpath);
		}
		
		if(@$this->list_config['basic']['disable_form']) {
			return new JForm($name);
		}
		
		if(empty($sources = $this->list_config['formfiles']['forms'])) {
			return false;
		}

		// Handle the optional arguments.
		$options['control'] = ArrayHelper::getValue($options, 'control', false);
		
		// Create a signature hash.
		$hash = md5($this->type . serialize($options));
	
		// Check if we can use a previously loaded form.
		if (isset($this->_forms[$hash]) && !$clear)
		{
			return $this->_forms[$hash];
		}
	
		// Get the form.
		JForm::addFormPath(JPATH_COMPONENT . '/models/forms');
		JForm::addFieldPath(JPATH_COMPONENT . '/models/fields');
		JForm::addFormPath(JPATH_COMPONENT . '/model/form');
		JForm::addFieldPath(JPATH_COMPONENT . '/model/field');
	
		try
		{
			$form = JForm::getInstance($name, reset($sources), $options, false, $xpath);
			
			while ($source = next($sources)) {
				$form->loadFile($source);
			}
			
			$data = (isset($options['load_data']) && $options['load_data']) ? $this->loadFormData() : array(); 
	
			// Allow for additional modification of the form, and events to be triggered.
			// We pass the data because plugins may require it.
			$this->preprocessForm($form, $data);
	
			// Load the data into the form after the plugins have operated.
			$form->bind($data);
		}
		catch (Exception $e)
		{
			$this->setError($e->getMessage());
	
			return false;
		}
	
		// Store the form for later.
		$this->_forms[$hash] = $form;
	
		return $form;
	}
	
	protected function loadFormData() {
		// Check the session for previously entered form data.
		$data = JFactory::getApplication()->getUserState('com_pswelder.edit.'.$this->type.'.data', array());
		if (empty($data)) {
			$data = $this->getItem($this->id);
		}
		
		return $data;
	}
	
	protected function loadItemData($pk) {
		$data = array();
		$tables = array($this->getTable());
		
		//@todo load other tables
		
		// load data from tables
		//@todo multi table with save column name
		foreach ($tables as $table) {
			if(!$table->load($pk)) {
				return false;
			}
			$data = array_merge($data, $table->getProperties());
		}
		
		JPluginHelper::importPlugin('content');
		$dispatcher = JEventDispatcher::getInstance();
		
		$result = $dispatcher->trigger('onItemPrepare', $data, $pk);
		
		
	}

	public function getItem($pk = null) {
		if($pk === null) {
			return null;
		}
		
		$return = $this->loadItemData((int) $pk);
		
		$table = $this->getTable();
		$return = $table->load($pk);
		// Check for a table object error.
		if ($return === false && $table->getError())
		{
			$this->setError($table->getError());
			return false;
		}
		// Convert to the JObject before adding other data.
		$properties = $table->getProperties();
		$item = JArrayHelper::toObject($properties, 'JObject');
		
		return $item;
	}
	
	public function save($data){
		$table = $this->getTable();
		$isnew = true;
		// Id exists, try to load it.
		if($this->id !== null) {
			$isnew = !$table->load($this->id);
		}
		$data[$this->list_config['tables'][$this->primary_table]['primary_key']] = $this->id;
		// Thrift is acquired, save data by the helper
		if(isset($this->list_config['thrift'])) {
			$data['thrift'] = $this->list_config['thrift'];
			$thrift_request = $this->prepareUpdateThriftData($data);
			
			$data['thrift']['request_data'] = json_encode($isnew ? $thrift_request : $this->prepareWhereThriftData(array($this->id), $this->list_config['database'][$this->primary_table]['primary_key'], $thrift_request));
			
			if(!$result = call_user_func(array('PswelderHelperItem', $isnew ? 'insert' : 'update'), $table, $data)) {
				return false;
			}
		} else {

			return $table->save($data);
		}
		return true;
	}
	
	public function delete($pks, $key = null){
		if(empty($key)) {
			$key = $this->list_config['database']['primary_key'];
		}
		if(isset($this->list_config['thrift'])) {
			$data = array('thrift' => $this->list_config['thrift']);
			$data['thrift']['request_data'] = json_encode($this->prepareWhereThriftData($pks, $key));
			if (PswelderHelperItem::delete($this->getTable(), $pks, $data))
				return true;
		}else {
			if ($this->getTable()->deleteItems($pks))
				return true;
		}
		
	}
	
	protected function prepareUpdateThriftData($data, $obj = null) {
		if(empty($obj)) {
			$obj = new stdClass();
		}
		
		$obj->columns = array();
		$obj->values = array();
		
		foreach ($this->list_config['thrift_maps'] as $key => $value) {
			$obj->columns[] = $key;
			$obj->values[] = isset($data[$value]) ? $data[$value] : '';
		}
		return $obj;
	}
	
	protected function prepareWhereThriftData($pks, $col_name, $obj = null) {
		if(empty($obj)) {
			$obj = new stdClass();
		}
		foreach ($this->list_config['thrift_maps'] as $key => $value) {
			if($value == $col_name) {
				$obj->where = new stdClass();
				$obj->where->$col_name = $pks;
				break;
			}
		}
		return $obj;
	}
	
	public function getItemID() {
		return $this->id;
	}
	
	public function getModelType() {
		return $this->type;
	}
	
	public function getListTitle() {
		return $this->list_config['basic']['title'];
	}
	public function getItemEditor() {
		
		return isset($this->list_config['basic']['editable']) ? $this->list_config['basic']['editable'] : true;
	}
	
}