<?php

/**
 * @package     Joomla.Site
 * @subpackage  com_weldresource
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

JLoader::register('PsweldHelperList',  JPATH_COMPONENT. '/helpers/list.php');

/**
 *
 * @todo User ArrayHelper::getValue to get value from config file
 *
 */

class PswelderModelList extends JModelList{
	protected $type;
	
	protected $list_config;
	
	protected $primary_table;
	
	protected $db_mysql;
	protected $db_orcl;
	
	public function __construct($config = array()) {
		if(!isset($config['modeltype']) || !file_exists($file = JPATH_COMPONENT . '/models/configs/' . $config['modeltype'] . '.ini')) {
			throw new RuntimeException('Invalid access of contents.');
		}
		
		$this->type = $config['modeltype'];
		
		//@todo User helper to get the configurations and check the configuration file contents
		if(!$this->list_config = parse_ini_file($file, true)) {
			throw new RuntimeException('Config File wrong');
		}

		// Check if the table for list is checked.
		if(empty($this->list_config['tables'])) {
			throw new RuntimeException('No table is set.');
		}
		
		$this->primary_table = @$this->list_config['primary_table'];
		
		if(!$this->primary_table){
			$this->primary_table = key($this->list_config['tables']);
		} else {
			if(!key_exists($this->primary_table, $this->list_config['tables'])) {
				throw new RuntimeException('Primary table is not set.');
			}
		}
		
		//Set up the filter form name
		//@todo Setu up the filter form automatic from the config file
		//@todo add form file
		$this->filterFormName = $this->list_config['formfiles']['filters'];
		
// 		if (empty($config['filter_fields']))
// 		{
// 			$config  =  array();
// 			foreach ($this->help->getConfig() as $value){
// 				$config[] = $value;
// 				$config[] = 'a'.$value;
// 			}
// 			$config['filter_fields'] = $config;
// 		}
		
		parent::__construct($config);
	}
	
	public function getFilterForm($data = array(), $loadData = true)
	{
		if (empty($this->filterFormName) || is_string($this->filterFormName)) {
			return parent::getFilterForm($data, $loadData);
		}
		
		$form = $this->loadForm($this->context . '.filter', reset($this->filterFormName), array('control' => '', 'load_data' => $loadData));
		
		while($formname = next($this->filterFormName)) {
			$form->loadFile($formname, false);
		}
	
		return $form;
	}
	
	public function getListQuery(){
		
		// Create a new query object.
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		
		if(count($this->list_config['tables']) == 1) {		//select from a single table
			$table = reset($this->list_config['tables']);
			
			$prefix = isset($table['alias']) ? $table['alias'] . '.' : '';
			$glue = isset($table['alias']) ? ', ' . $prefix : ', ';
				
			$query->select($prefix . implode($glue, array_keys($this->list_config['list'])));
			$query->from('#__' . key($this->list_config['tables']) . ' AS ' . (isset($table['alias']) ? $table['alias'] : 'list'));
		} else{ // select from one or more tables, the columns must be listed as array of an element in list
			$query->select(implode(',', array_keys($this->list_config['list'])));
			
			foreach ($this->list_config['tables'] as $t_name => $table) {
				
				// In multi table mode, alias is required. 
				if (!isset($table['alias'])) {
					throw new RuntimeException('Alias is required for tabel "' . $t_name . '" in multi-table mode.');
				}
				
				if(isset($table['join'])) {
					if(empty(@$table['join_on'])) {
						throw new RuntimeException('No Join option is set');
					}
					
					$query->join($table['join'], '#__' . $t_name . ' AS ' . $table['alias'] . ' ON ' . $table['join_on']);
				} else {
					$query->from('#__' . $t_name . (isset($table['alias']) ? ' AS ' . $table['alias'] : ''));
				}
			}
		}

// 		$query->select(implode(',', array_keys($this->list_config['list'])));
// 		$query->from('#__' . $this->list_config['database']['mysql'] . ' AS list');
		
		// Select the required fields from the table.
// 		$query->select(
// 				$this->getState('list.select',implode(',', array_keys($this->help->getSelect())))
// 				);
// 		$query->from('#__resource_'.$this->weld.' AS a');
		
		
// 		foreach ($this->help->getConfig() as $value){
// 			if ($name = $this->getState('filter.'.$value))
// 			{
// 				$query->where('a.'.$value.' = ' . $db->quote($name));
// 			}
// 		}
		
		
// 		// Filter by search in title.
// 		$search = $this->getState('filter.search');
		
// 		if (!empty($search))
// 		{
// 			if (stripos($search, 'id:') === 0)
// 			{
// 				$query->where('a.id = ' . (int) substr($search, 3));
// 			}
// 			else
// 			{
// 				$search = $db->quote('%' . str_replace(' ', '%', $db->escape(trim($search), true) . '%'));
// 				$query->where('(a.name LIKE ' . $search . ')');
// 			}
// 		}
		
		
// 		$orderCol	= $this->state->get('list.ordering', 'a.id');
// 		$orderDirn 	= $this->state->get('list.direction', 'desc');
// 		$query->order($db->escape($orderCol) . ' ' . $db->escape($orderDirn));
		
		return $query;
	}
	
	public function getListTitle() {
		return $this->list_config['basic']['title'];
	}
	
	public function getListContent() {
		return $this->list_config['list'];
		
	}
	
	public function getListContentKeys() {
		$spliter = array(" ", ".");
		
		$regex = '/(' . implode('|', array_map(function($string) {
					return preg_quote($string);
				}, $spliter)) . ')/';
				
		$keys = array_keys($this->list_config['list']);
		foreach ($keys as &$key) {
			$strs = preg_split($regex, $key);
			$key = end($strs);
		}
		return $keys;
	}
	
	public function getModelType() {
		return $this->type;
	}
	
	public function getPrimaryKey() {
		return $this->list_config['tables'][$this->primary_table]['primary_key'];
	}
	
	public function getItemEditable() {
		
		return isset($this->list_config['basic']['editable']) ? $this->list_config['basic']['editable'] : true;
	}
		
}
